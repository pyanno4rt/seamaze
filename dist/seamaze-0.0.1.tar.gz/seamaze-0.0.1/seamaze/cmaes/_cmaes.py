"""Covariance matrix adaptation evolution strategy (CMA-ES)."""

# Authors: Tim Ortkamp, Chinmay Patwardhan, Pia Stammer

# %% External package import

from time import time

from collections import deque
from math import inf
from numba import njit
from numpy import (
    add, arange, argmin, argsort, array, clip, exp, eye, float64, full, log,
    matmul, maximum, median, ones, sqrt, zeros)
from numpy import sum as nsum
from numpy.linalg import norm
from numpy.random import default_rng
from scipy.linalg import eigh

# %% Covariance matrix adaptation evolution algorithm


class CMAES:
    """
    Covariance matrix adaptation evolution strategy class.

    This class implements the CMA-ES algorithm.

    Parameters
    ----------
    number_of_variables : int
        Dimension of the search space (number of decision variables).

    objective : Callable[[ndarray], float]
        The objective function to be minimized. Must accept a 1D ``ndarray`` \
        and return a scalar ``float``.

    gradient : Callable[[ndarray], ndarray], optional
        Optional gradient function used for hybrid evolution steps.

    lower_variable_bounds : ndarray, default=None
        Lower bounds on the decision variables. Must be a 1D array of length \
        `number_of_variables`. Defaults to -inf for all variables.

    upper_variable_bounds : ndarray, default=None
        Upper bounds on the decision variables. Must be a 1D array of length \
        `number_of_variables`. Defaults to +inf for all variables.

    number_of_individuals : int, default=None
        Population size. Defaults to 4 + int(3*log(`number_of_variables`)).

    initial_sigma : float, default=0.3
        Initial step size (standard deviation).

    maximum_iterations : int, default=1000
        Maximum number of generations (iterations) to run before stopping.

    maximum_wall_time : int or float, default=7200
        Maximum allowed wall-clock time in seconds.

    fitness_threshold : int or float, default=-inf
        Target fitness value. If the objective value reaches this threshold, \
        optimization stops (success criterion).

    fitness_window_size : int, default=20
        Number of past iterations to consider for the median fitness \
        stagnation check.

    tolerance : float, default=1e-3
        Absolute and relative termination tolerance: stops if the change in \
        median fitness over `fitness_window_size` is below this value.

    sigma_threshold : float, default=1e-3
        Minimum allowed step size. If the step size falls below this limit, \
        optimization stops (convergence/collapse criterion).

    store_singular_values : bool, default=False
        Indicator for recording the history of singular values (eigenvalues) \
        of the covariance matrix for later analysis.

    update_interval : int, default=1
        Frequency of the low-rank update (in generations). Larger values \
        (e.g. 10) can significantly speed up the algorithm for \
        high-dimensional problems.

    rank : None or int, default=None
        Rank of the covariance matrix approximation. If specified, a low-rank \
        update is performed. Defaults to `number_of_variables`.

    callback : Callable[[dict], None], default=None
        Optional function called at the end of each iteration. Must accept a \
        dictionary with the current results.
    """

    def __init__(
            self,
            number_of_variables,
            objective,
            gradient=None,
            lower_variable_bounds=None,
            upper_variable_bounds=None,
            number_of_individuals=None,
            initial_sigma=0.3,
            maximum_iterations=1000,
            maximum_wall_time=7200,
            fitness_threshold=-inf,
            fitness_window_size=20,
            tolerance=1e-3,
            sigma_threshold=1e-3,
            store_singular_values=False,
            update_interval=1,
            rank=None,
            callback=None):

        # Set the random seed
        self._rng = default_rng(42)

        # Initialize the optimization problem variables
        self._number_of_variables = number_of_variables
        self.objective = objective
        self.gradient = gradient
        self.lower_variable_bounds = (
            full(self._number_of_variables, -inf)
            if lower_variable_bounds is None else lower_variable_bounds)
        self.upper_variable_bounds = (
            full(self._number_of_variables, inf)
            if upper_variable_bounds is None else upper_variable_bounds)
        self._rank = (
            self._number_of_variables if rank is None
            else min(rank, self._number_of_variables))

        # Initialize the low-rank variables
        self._store_singular_values = store_singular_values
        self._singular_values = []
        self._update_interval = update_interval

        # Initialize the population and elite sizes
        self._pop_size = (
            4 + int(3*log(self._number_of_variables))
            if number_of_individuals is None else number_of_individuals)
        self._pop_size += (2 if gradient is not None else 0)
        self._elite_size = self._pop_size // 2

        # Initialize the weights and variance effective selection mass
        base_weights = (
            log(self._elite_size + 0.5) - log(arange(1, self._elite_size + 1))
            )
        self._weights = base_weights / nsum(base_weights)
        self._mu_eff = 1 / nsum(self._weights**2)

        # Initialize the learning rates
        self._lr_sigma = (self._mu_eff + 2) / (self._rank + self._mu_eff + 3)
        self._lr_cov = 4 / (self._rank + 4)
        self._lr_rank_1 = (
            2 * min(1, self._pop_size/6) /
            ((self._rank + 1.3)**2 + self._mu_eff))
        self._lr_rank_mu = (
            2*(self._mu_eff + 1/self._mu_eff - 2) /
            ((self._rank + 2)**2 + self._mu_eff))
        self._lr_mean = 1.0

        # Initialize the damping coefficient
        self._damp_sigma = (
            1 + 2*max(0, sqrt((self._mu_eff - 1) / self._rank) - 1)
            + self._lr_sigma)

        # Initialize the expected path length
        self._expected_path_length = (
            sqrt(self._number_of_variables) * (
                1
                - 1/(4*self._number_of_variables)
                + 1/(21*self._number_of_variables**2))
            )

        # Initialize the adaptive variables
        self._wall_start = None
        self._opt_iter = 0

        self._steps = zeros(
            (self._pop_size, self._number_of_variables),
            order='F', dtype=float64)
        self._population = zeros(
            (self._pop_size, self._number_of_variables),
            order='F', dtype=float64)

        self._sigma = initial_sigma

        self._path_sigma = zeros(self._number_of_variables, dtype=float64)
        self._path_cov = zeros(
            (self._number_of_variables, 1), order='F', dtype=float64)
        self._mean = zeros(self._number_of_variables, dtype=float64)
        self._cov = eye(self._number_of_variables, dtype=float64)

        self._left_basis = eye(
            self._number_of_variables, self._rank, order='F', dtype=float64)
        self._core_vector = ones(self._rank, dtype=float64)
        self._root_cov = eye(
            self._number_of_variables, self._rank, order='F', dtype=float64)

        # Initialize the stopping criteria and tracking variables
        self.maximum_iterations = maximum_iterations
        self.maximum_wall_time = maximum_wall_time
        self.fitness_threshold = fitness_threshold
        self.sigma_threshold = sigma_threshold or 0.0
        self.tolerance = tolerance
        self._fitness_history = deque(maxlen=fitness_window_size)
        self._callback = callback
        self._result = {
            'optimal_point': None, 'optimal_value': inf, 'solver_info': None,
            'wall_time': None}

    def ask(self):
        """
        Generate a new population.

        Returns
        -------
        ndarray
            Sample population (bound to the feasible region).

        ndarray
            Sample steps.
        """

        # Sample from the standard multivariate Gaussian
        zsamples = self._rng.standard_normal((self._pop_size, self._rank))

        # Sample steps from the multivariate Gaussian
        matmul(zsamples, self._root_cov.T, out=self._steps)

        # Check if a gradient has been provided
        if self.gradient is not None:

            # Compute the gradient
            gradient = self.gradient(self._mean)

            # Compute the unscaled natural gradient
            natural_gradient = self._cov @ gradient

            # Compute the rescaling factor
            rescale = 1 / (sqrt(gradient @ natural_gradient) + 1e-15)

            # Compute the natural gradient step
            gradient_step = natural_gradient * rescale

            # Add the gradient steps (with mirroring)
            self._steps[-2] = -gradient_step
            self._steps[-1] = gradient_step

        # Sample the new population
        add(self._mean, self._sigma * self._steps, out=self._population)

        # Get the "feasible" population
        clip(
            self._population, a_min=self.lower_variable_bounds,
            a_max=self.upper_variable_bounds, out=self._population)

    def evaluate(self):
        """
        Evaluate the fitness of the population and track the global optimum.

        Returns
        -------
        ndarray
            Fitness values for the population.
        """

        # Compute the fitness values
        fitness = array([
            self.objective(individual, track=False)
            for individual in self._population])

        # Get the best fitness
        best_index = argmin(fitness)
        best_fitness = fitness[best_index]

        # Append the best fitness to the history
        self._fitness_history.append(best_fitness)

        # Check if an improved solution has been found
        if self._result['optimal_value'] - best_fitness > 0:

            # Update the optimal value and point
            self._result['optimal_value'] = best_fitness
            self._result['optimal_point'] = self._population[best_index].copy()

        # Re-evaluate the current best individual for tracking
        self.objective(self._result['optimal_point'])

        return fitness

    def tell(
            self,
            fitness):
        """
        Update the adaptive variables.

        Parameters
        ----------
        fitness : ndarray
            Fitness values of the new population.
        """

        # Update the basis variables
        self._sigma = _tell(
            fitness, self._steps, self._weights, self._left_basis,
            self._core_vector, self._path_sigma, self._path_cov, self._mean,
            self._sigma, self._cov, self._lr_sigma, self._lr_cov,
            self._lr_mean, self._lr_rank_1, self._lr_rank_mu, self._mu_eff,
            self._damp_sigma, self._expected_path_length, self._opt_iter,
            self._elite_size, self._rank)

        # Check if the low-rank factors should be updated
        if self._opt_iter % self._update_interval == 0:

            # Update the low-rank factors
            self._core_vector, self._left_basis = eigh(
                self._cov, overwrite_a=True, check_finite=False)

            # Sort the singular values and vectors in descending order
            self._core_vector = self._core_vector[::-1]
            self._left_basis = self._left_basis[:, ::-1]

            # Check if the selected rank is lower than the dimensionality
            if self._rank < self._number_of_variables:

                # Get the energy scaling
                energy_scale = (
                    nsum(self._core_vector) /
                    (nsum(self._core_vector[:self._rank]) + 1e-15)
                    )

                # Rescale the truncated singular values
                self._core_vector = (
                    self._core_vector[:self._rank] * energy_scale)

                # Truncate the singular vectors
                self._left_basis = self._left_basis[:, :self._rank]

            # Clip the singular values
            maximum(self._core_vector, 1e-12, out=self._core_vector)

            # Check if singular values should be stored
            if self._store_singular_values:

                # Append the singular values
                self._singular_values.append(self._core_vector)

            # Symmetrize the covariance matrix for stability
            self._cov = (
                (self._left_basis * self._core_vector) @ self._left_basis.T)

            # Update the sampling matrix
            self._root_cov = self._left_basis * sqrt(self._core_vector)

    def optimize(
            self,
            initial_mean=None):
        """
        Run the optimization algorithm.

        Parameters
        ----------
        initial_mean : ndarray, default=None
            Initial mean vector. Default corresponds to the zero vector.

        Returns
        -------
        dict
            Dictionary with the optimization results.
        """

        # Start the runtime recordings
        self._wall_start = time()

        # Check if an initial mean has been provided
        if initial_mean is not None:

            # Set the initial mean
            self._mean = initial_mean

        # Continue until termination criteria are fulfilled
        while self.check_termination() is False:

            # "Ask" for a new population
            self.ask()

            # Evaluate the population's fitness
            fitness = self.evaluate()

            # "Tell" the algorithm to update its parameters
            self.tell(fitness)

            # Check if a callback has been provided
            if self._callback is not None:

                # Pass the current results to the callback
                self._callback(self._result)

            # Increment the iteration counter
            self._opt_iter += 1

        # Store the runtimes
        self._result['wall_time'] = time()-self._wall_start

        return self._result

    def check_termination(self):
        """
        Check the termination criteria.

        Returns
        -------
        bool
            Indicator for termination.
        """

        # Check if the maximum number of iterations has been reached
        if self._opt_iter >= self.maximum_iterations:

            # Add the solver info
            self._result['solver_info'] = 'MAX_ITER_REACHED'

            return True

        # Check if the wall clock timer has been started
        if self._wall_start is not None:

            # Check if the maximum runtime has been reached
            if time()-self._wall_start >= self.maximum_wall_time:

                # Add the solver info
                self._result['solver_info'] = 'MAX_WALL_TIME_REACHED'

                return True

        # Check if the step size is below the threshold
        if self._sigma <= self.sigma_threshold:

            # Add the solver info
            self._result['solver_info'] = 'SIGMA_BELOW_THRESH'

            return True

        # Check if the fitness history is non-empty
        if len(self._fitness_history) > 0:

            # Check if the optimal value is below a threshold
            if (self.fitness_threshold is not None
                    and self._fitness_history[-1] < self.fitness_threshold):

                # Add the solver info
                self._result['solver_info'] = 'FITNESS_BELOW_THRESH'

                return True

        # Check if the history is completely filled
        if len(self._fitness_history) == self._fitness_history.maxlen:

            # Converthe history to a list
            history = list(self._fitness_history)

            # Get the first and second half median
            first_median = median(history[:len(history) // 2])
            second_median = median(history[len(history) // 2:])

            # Check if the absolute median difference is below tolerance
            if abs(first_median - second_median) < self.tolerance:

                # Add the solver info
                self._result['solver_info'] = (
                    'ABSOLUTE_FITNESS_PLATEAU_REACHED')

                return True

            # Get the relative median difference
            diff = (
                abs(first_median - second_median) /
                (abs(second_median) + 1e-15))

            # Check if the relative median difference is below tolerance
            if diff < self.tolerance:

                # Add the solver info
                self._result['solver_info'] = (
                    'RELATIVE_FITNESS_PLATEAU_REACHED')

                return True

        return False


@njit(fastmath=True)
def _tell(
    fitness, steps, weights, left_basis, core_vector, path_sigma, path_cov,
    mean, sigma, cov, lr_sigma, lr_cov, lr_mean, lr_rank_1, lr_rank_mu,
    mu_eff, damp_sigma, expected_path_length, opt_iter, elite_size, rank):
    """Update the basic CMAES variables."""

    # Get the indices of the elite fitness values
    elite_indices = argsort(fitness)[:elite_size]

    # Get the number of variables
    number_of_variables = mean.shape[0]

    # Initialize the elite mean step
    elite_mean_step = zeros(number_of_variables)

    # Loop over the elite size
    for elite_idx in range(elite_size):

        # Get the sample index
        sample_index = elite_indices[elite_idx]

        # Get the associated weight
        weight = weights[elite_idx]

        # Loop over the number of variables
        for var_idx in range(number_of_variables):

            # Update the elite mean step element
            elite_mean_step[var_idx] += weight * steps[sample_index, var_idx]

    # Calculate the inverse rooted eigenvalues
    inv_root_core_vec = 1.0 / (sqrt(core_vector) + 1e-15)

    # Transform the elite mean step
    latent_step = left_basis.T @ elite_mean_step
    elite_mean_step_tr = left_basis @ (inv_root_core_vec * latent_step)

    # Update the step-size evolution path
    path_sigma *= (1.0 - lr_sigma)
    path_sigma += (
        sqrt(lr_sigma * (2.0 - lr_sigma) * mu_eff)
        * elite_mean_step_tr)

    # Get the norm of the step-size evolution path
    ps_norm = norm(path_sigma)

    # Compute the update switch for the covariance matrix
    update_switch = (
        1.0
        if ps_norm / sqrt(1 - (1-lr_sigma)**(2*(opt_iter + 1)))
        < (1.4 + 2/(rank+1)) * expected_path_length
        else 0.0)

    # Compute the 'keep' term of the evolution path
    path_cov *= (1.0 - lr_cov)

    # Precompute the coefficient
    coeff = update_switch * sqrt(lr_cov * (2.0 - lr_cov) * mu_eff)

    # Loop over the number of variables
    for var_idx in range(number_of_variables):

        # Update the evolution path element
        path_cov[var_idx, 0] += coeff * elite_mean_step[var_idx]

    # Update the mean
    mean += (lr_mean * sigma) * elite_mean_step

    # Update the step size
    sigma_update = sigma * exp(
        (lr_sigma / damp_sigma) * (ps_norm / expected_path_length - 1))

    # Check if the updated sigma is lower than 1e-15
    if sigma_update < 1e-15:

        # Clip to 1e-15
        sigma_update = 1e-15

    # Else, check if the updated sigma is above 1.0
    elif sigma_update > 1.0:

        # Clip to 1.0
        sigma_update = 1.0

    # Get the adjusted rank-1 learning rate
    lr_rank_1_adj = (1.0-update_switch) * lr_rank_1 * lr_cov * (2.0-lr_cov)

    # Get the elite steps
    elite_steps = steps[elite_indices]

    # Initialize the weighted elite steps
    weighted_elite_steps = zeros(elite_steps.shape)

    # Loop over the elite size
    for elite_idx in range(elite_size):

        # Enter the weighted elite steps element
        weighted_elite_steps[elite_idx] = (
            weights[elite_idx] * elite_steps[elite_idx])

    # Compute the rank-mu update
    rank_mu_term = elite_steps.T @ weighted_elite_steps

    # Update the covariance matrix
    cov *= (1 - lr_rank_1 - lr_rank_mu + lr_rank_1_adj)
    cov += lr_rank_1 * (path_cov @ path_cov.T)
    cov += lr_rank_mu * rank_mu_term

    return sigma_update

# %% Toy problem class

from math import pi
from numpy import cos, sin

class ToyProblem:
    """
    A toy problem class to test the CMA algorithm with different benchmark \
    functions.

    Parameters
    ----------
    name : {'rastrigin', 'sphere', 'styblinski-tang'}
        Name of the test function.

    initial_x : ndarray
        Initial decision variables.

    Attributes
    ----------
    name : {'rastrigin', 'sphere', 'styblinski-tang'}
        See 'Parameters'.

    f : function
        Objective function.

    g : function
        Gradient function.

    variable_bounds : tuple
        Tuple with two lists for the lower and upper variable bounds.
    """

    def __init__(
            self,
            name,
            x0):

        # Get the function name
        self.name = name
        self.x0 = x0

        # Map the names
        functions = {
            'rastrigin': self.rastrigin,
            'sphere': self.sphere,
            'styblinski-tang': self.styblinski_tang}

        # Get the objective and gradient functions
        self.f, self.g, self.variable_bounds = functions[name]()

    def objective(self, x):
        """
        Compute the objective.

        Parameters
        ----------
        x : ndarray
            Decision vector.

        Returns
        -------
        int or float
            Objective value.
        """

        return self.f(x)

    def gradient(
            self,
            x):
        """
        Compute the gradient.

        Parameters
        ----------
        x : ndarray
            Decision vector.

        Returns
        -------
        ndarray
            Gradient.
        """

        return self.g(x)

    def rastrigin(self):
        """
        Rastrigin function.

        Global minimum: f(0,...,0) = 0.0, search domain: [-5.12, 5.12].
        """

        def f(x, track=False):
            return 10*len(x) + sum(x**2 - 10*cos(2*pi*x))

        def g(x):
            return 2*x+20*pi*sin(2*pi*x)

        bounds = ([-5.12]*len(self.x0), [5.12]*len(self.x0))

        return f, g, bounds

    def sphere(self):
        """
        Sphere function.

        Global minimum: f(0,...,0) = 0.0, search domain: [-inf, inf].
        """

        def f(x, track=False):
            return sum(x**2)

        def g(x):
            return 2.0*x

        bounds = ([-inf]*len(self.x0), [inf]*len(self.x0))

        return f, g, bounds

    def styblinski_tang(self):
        """
        Styblinski-Tang function.

        Global minimum: -39.16617*len(x) < f(-2.903534,...,-2.903534) \
        < -39.16616*len(x), search domain: [-5, 5].
        """

        def f(x, track=False):
            return sum(x**4-16*x**2+5*x)/2

        def g(x):
            return 2.0*x**3-16*x+2.5

        bounds = ([-5.0]*len(self.x0), [5.0]*len(self.x0))

        return f, g, bounds


# %% Test run

# Set the initial vector
initial_x = array([5.0]*2)

# Initialize the toy problem
prob = ToyProblem(
    name='styblinski-tang',
    x0=initial_x)

# Initialize the CMA solver
solver = CMAES(
    number_of_variables=len(initial_x),
    objective=prob.f,
    gradient=prob.g,
    lower_variable_bounds=array(prob.variable_bounds[0]),
    upper_variable_bounds=array(prob.variable_bounds[1]),
    number_of_individuals=100,
    initial_sigma=2.0,
    maximum_iterations=200,
    maximum_wall_time=7200,
    fitness_threshold=None,
    fitness_window_size=30,
    tolerance=1e-3,
    sigma_threshold=1e-3,
    store_singular_values=False,
    update_interval=1,
    rank=None,
    callback=None)

# Optimize the variables
result = solver.optimize(initial_x)

# Get the iteration-wise eigenvalues
sv = solver._singular_values

# %% Plot covariance matrix over function

# import numpy as np
# import matplotlib
# matplotlib.use('Qt5Agg')
# import matplotlib.pyplot as plt

# def plot_iter_sv(svals, iteration, fname, k):
#     """Plot the singular values for a fixed iteration."""

#     # Plotting on a semi-log scale (y-axis is logarithmic)
#     plt.figure(figsize=(10, 6))

#     #
#     values = svals[iteration][:k]

#     # Plot the singular values
#     plt.semilogy(values, marker='o', linestyle='-', color='b')

#     plt.title(f'{fname} (iteration {iteration})', fontweight='bold')
#     plt.ylabel('Singular Value ($\sigma_i$) (log scale)')
#     plt.xlabel('Singular Value Index')
#     # plt.xticks([i for i in range(len(values))])
#     plt.grid(True, which="both", ls="--", color='0.7')
#     plt.savefig(f'/home/tim/Downloads/{fname}_{iteration}.pdf')
#     plt.show()

# plot_iter_sv(sv, 0, prob.name, 20)
# plot_iter_sv(sv, len(sv)//2, prob.name, 20)
# plot_iter_sv(sv, len(sv)-1, prob.name, 20)

# def plot_sv_paths(svals, fname, space):
#     """Plot the iteration-wise singular value paths."""

#     # Plotting on a semi-log scale (y-axis is logarithmic)
#     plt.figure(figsize=(10, 6))

#     # Plot the singular values
#     for values in zip(*svals):

#         #
#         subvalues = values[::space]

#         #
#         plt.semilogy(
#             array(range(len(subvalues)))*space, subvalues, marker='.',
#             linestyle='-', color='b')

#     plt.title(f'{fname}', fontweight='bold')
#     plt.ylabel('Singular Value ($\sigma_i$) (log scale)')
#     plt.xlabel('Optimization iteration')
#     plt.grid(True, which="both", ls="--", color='0.7')
#     plt.savefig(f'/home/tim/Downloads/{fname}.pdf')
#     plt.show()

# plot_sv_paths(sv, prob.name, 1)

# # Interactive plotting
# plt.ion()

# # Create plot
# fig = plt.figure(figsize=(10, 8))
# ax = fig.add_subplot(111, projection='3d')
# ax.view_init(elev=30, azim=-45)

# def update_plot(iteration, mu_2d, cov_2d, svs):

#     # Clear the axis
#     ax.clear()

#     # Create meshgrid
#     x_range = np.linspace(-5, 5, 50)
#     y_range = np.linspace(-5, 5, 50)
#     X, Y = np.meshgrid(x_range, y_range)

#     # Plot function as surface
#     Z = prob.f(array([X, Y]))
#     ax.plot_surface(
#         X, Y, Z, cmap='viridis', alpha=0.3, antialiased=True, zorder=5)

#     # Plot mean vector
#     mu_z = prob.f(array([mu_2d[0], mu_2d[1]]))
#     ax.text(mu_2d[0], mu_2d[1], mu_z, "●", color='orange', fontsize=14,
#             ha='center', va='center', zorder=100)

#     # Compute the circle
#     vals, vecs = np.linalg.eig(cov_2d)
#     t = np.linspace(0, 2*np.pi, 100)
#     circle = np.stack([np.cos(t), np.sin(t)])

#     # Transform into ellipsoid
#     scaling = 3 * np.sqrt(np.maximum(vals, 0))
#     ellipse_points = (vecs @ (scaling[:, None] * circle))

#     # Compute the center of the ellipsoid
#     ell_x = ellipse_points[0, :] + mu_2d[0]
#     ell_y = ellipse_points[1, :] + mu_2d[1]

#     # Compute the z-level of the ellipsoid
#     ell_z = [mu_z]*100

#     # Plot covariance matrix
#     ax.plot(
#         ell_x, ell_y, ell_z, color='red', linewidth=3, label="3σ ellipse",
#         zorder=5)

#     # Add the mean and singular values
#     s_vals = np.sqrt(np.maximum(vals, 0))
#     label_txt = (
#         f"mean: {(round(float(mu_2d[0]), 4), round(float(mu_2d[1]), 4))}"
#         f"\nλ1: {s_vals[0]:.2f}\nλ2: {s_vals[1]:.2f}")
#     ax.text(
#         mu_2d[0], mu_2d[1], mu_z+10,
#         label_txt, zorder=10,
#         bbox=dict(
#             facecolor='white', edgecolor='black', boxstyle='round,pad=0.5'))

#     ax.set_xlabel('X'); ax.set_ylabel('Y'); ax.set_zlabel('Z')
#     ax.set_title(f"Iteration: {iteration+1}")
#     plt.draw()
#     plt.pause(3)
#     plt.show()

# plt.pause(10)
# plt.close()