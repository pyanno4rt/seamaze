"""
Plotting module.

==================================================================

This module aims to provide methods and classes for plotting.
"""

# Author: Tim Ortkamp, Chinmay Patwardhan, Pia Stammer

from seamaze.plotting._plot_bound_violations import plot_bound_violations
from seamaze.plotting._plot_fitness import plot_fitness
from seamaze.plotting._plot_matrix_slices import plot_matrix_slices
from seamaze.plotting._plot_series import plot_series

from seamaze.plotting._result_plotter import ResultPlotter
from seamaze.plotting._visualizer import Visualizer

__all__ = [
    'plot_bound_violations',
    'plot_fitness',
    'plot_matrix_slices',
    'plot_series',
    'ResultPlotter',
    'Visualizer']
